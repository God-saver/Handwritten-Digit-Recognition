"""
app.py — Flask backend for MNIST digit recognition
Serves the UI and exposes prediction + info APIs.
"""

import os
import io
import json
import base64
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
from PIL import Image, ImageOps
import tensorflow as tf
from tensorflow import keras

app = Flask(__name__, static_folder='static')

# ──────────────────────────────────────────
# LOAD MODEL
# ──────────────────────────────────────────
MODEL_PATH = 'model/mnist_cnn.h5'
HISTORY_PATH = 'model/training_history.json'

model = None
training_history = {}

def load_model():
    global model, training_history
    if os.path.exists(MODEL_PATH):
        print(f"Loading model from {MODEL_PATH}...")
        model = keras.models.load_model(MODEL_PATH)
        print("✅ Model loaded.")
    else:
        print("⚠️  Model not found. Run train.py first!")

    if os.path.exists(HISTORY_PATH):
        with open(HISTORY_PATH) as f:
            training_history = json.load(f)

load_model()

# ──────────────────────────────────────────
# PREPROCESSING
# ──────────────────────────────────────────
def preprocess_image(image_data: str) -> np.ndarray:
    """
    Accepts base64 PNG/JPG (from canvas or file upload).
    Returns float32 array of shape (1, 28, 28, 1).
    """
    # Strip data URL prefix
    if ',' in image_data:
        image_data = image_data.split(',')[1]

    img_bytes = base64.b64decode(image_data)
    img = Image.open(io.BytesIO(img_bytes)).convert('L')  # grayscale

    # If white-on-black (canvas), keep as is; if black-on-white, invert
    img_array = np.array(img)
    if img_array.mean() > 127:
        img = ImageOps.invert(img)

    # Resize to 28×28
    img = img.resize((28, 28), Image.LANCZOS)

    # Normalize
    arr = np.array(img).astype('float32') / 255.0
    arr = arr.reshape(1, 28, 28, 1)
    return arr

# ──────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({'error': 'Model not loaded. Run train.py first.'}), 503

    data = request.json
    if not data or 'image' not in data:
        return jsonify({'error': 'No image data provided'}), 400

    try:
        arr = preprocess_image(data['image'])
        predictions = model.predict(arr, verbose=0)[0]

        digit = int(np.argmax(predictions))
        confidence = float(predictions[digit])

        all_probs = {str(i): round(float(predictions[i]) * 100, 2) for i in range(10)}
        top3 = sorted(all_probs.items(), key=lambda x: x[1], reverse=True)[:3]

        return jsonify({
            'digit': digit,
            'confidence': round(confidence * 100, 2),
            'probabilities': all_probs,
            'top3': [{'digit': int(d), 'probability': p} for d, p in top3]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/model-info', methods=['GET'])
def model_info():
    if model is None:
        return jsonify({'error': 'Model not loaded'}), 503

    total_params = int(model.count_params())
    layers_info = []
    for layer in model.layers:
        cfg = layer.get_config()
        layers_info.append({
            'name': layer.name,
            'type': layer.__class__.__name__,
            'output_shape': str(layer.output_shape),
            'params': int(layer.count_params())
        })

    return jsonify({
        'total_params': total_params,
        'layers': layers_info,
        'test_accuracy': training_history.get('test_accuracy', None),
        'test_loss': training_history.get('test_loss', None),
        'epochs_trained': training_history.get('epochs_trained', None),
        'history': {
            'accuracy':     training_history.get('accuracy', []),
            'val_accuracy': training_history.get('val_accuracy', []),
            'loss':         training_history.get('loss', []),
            'val_loss':     training_history.get('val_loss', []),
        }
    })

@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({
        'model_loaded': model is not None,
        'model_path': MODEL_PATH,
        'has_history': bool(training_history)
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
