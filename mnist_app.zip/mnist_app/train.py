"""
train.py — Train CNN on MNIST dataset using TensorFlow/Keras
Run this once to generate: model/mnist_cnn.h5
"""

import os
import json
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

os.makedirs('model', exist_ok=True)

# ──────────────────────────────────────────
# 1. LOAD & PREPROCESS DATA
# ──────────────────────────────────────────
print("Loading MNIST dataset...")
(X_train, y_train), (X_test, y_test) = keras.datasets.mnist.load_data()

# Normalize to [0, 1] and reshape to (N, 28, 28, 1)
X_train = X_train.astype('float32') / 255.0
X_test  = X_test.astype('float32') / 255.0
X_train = X_train[..., np.newaxis]
X_test  = X_test[..., np.newaxis]

# One-hot encode labels
y_train_cat = keras.utils.to_categorical(y_train, 10)
y_test_cat  = keras.utils.to_categorical(y_test,  10)

print(f"Train: {X_train.shape} | Test: {X_test.shape}")

# ──────────────────────────────────────────
# 2. DATA AUGMENTATION
# ──────────────────────────────────────────
datagen = keras.preprocessing.image.ImageDataGenerator(
    rotation_range=10,
    zoom_range=0.1,
    width_shift_range=0.1,
    height_shift_range=0.1
)
datagen.fit(X_train)

# ──────────────────────────────────────────
# 3. BUILD CNN MODEL
# ──────────────────────────────────────────
def build_model():
    model = keras.Sequential([
        # Block 1
        layers.Conv2D(32, (3,3), activation='relu', padding='same', input_shape=(28,28,1)),
        layers.BatchNormalization(),
        layers.Conv2D(32, (3,3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2,2)),
        layers.Dropout(0.25),

        # Block 2
        layers.Conv2D(64, (3,3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.Conv2D(64, (3,3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2,2)),
        layers.Dropout(0.25),

        # Block 3
        layers.Conv2D(128, (3,3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.Dropout(0.25),

        # Classifier head
        layers.Flatten(),
        layers.Dense(256, activation='relu'),
        layers.BatchNormalization(),
        layers.Dropout(0.5),
        layers.Dense(10, activation='softmax')
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    return model

model = build_model()
model.summary()

# ──────────────────────────────────────────
# 4. CALLBACKS
# ──────────────────────────────────────────
callbacks = [
    EarlyStopping(patience=5, restore_best_weights=True, verbose=1),
    ReduceLROnPlateau(factor=0.5, patience=3, min_lr=1e-6, verbose=1),
    ModelCheckpoint('model/mnist_cnn.h5', save_best_only=True, verbose=1)
]

# ──────────────────────────────────────────
# 5. TRAIN
# ──────────────────────────────────────────
print("\nTraining CNN...")
history = model.fit(
    datagen.flow(X_train, y_train_cat, batch_size=128),
    epochs=20,
    validation_data=(X_test, y_test_cat),
    callbacks=callbacks,
    verbose=1
)

# ──────────────────────────────────────────
# 6. EVALUATE
# ──────────────────────────────────────────
test_loss, test_acc = model.evaluate(X_test, y_test_cat, verbose=0)
print(f"\n✅ Test Accuracy: {test_acc*100:.2f}%  |  Test Loss: {test_loss:.4f}")

# Save training history
history_data = {
    'accuracy':     [float(v) for v in history.history['accuracy']],
    'val_accuracy': [float(v) for v in history.history['val_accuracy']],
    'loss':         [float(v) for v in history.history['loss']],
    'val_loss':     [float(v) for v in history.history['val_loss']],
    'test_accuracy': float(test_acc),
    'test_loss':     float(test_loss),
    'epochs_trained': len(history.history['accuracy'])
}
with open('model/training_history.json', 'w') as f:
    json.dump(history_data, f, indent=2)

# ──────────────────────────────────────────
# 7. PLOT TRAINING CURVES
# ──────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
fig.patch.set_facecolor('#0d0d14')

for ax in axes:
    ax.set_facecolor('#0d0d14')
    ax.tick_params(colors='#888', labelsize=9)
    for spine in ax.spines.values():
        spine.set_edgecolor('#2a2a3a')

epochs_range = range(1, len(history.history['accuracy']) + 1)

axes[0].plot(epochs_range, history.history['accuracy'],     color='#00d4ff', linewidth=2, label='Train')
axes[0].plot(epochs_range, history.history['val_accuracy'], color='#ff6b6b', linewidth=2, label='Validation')
axes[0].set_title('Model Accuracy', color='white', fontsize=13, pad=12)
axes[0].set_xlabel('Epoch', color='#888')
axes[0].set_ylabel('Accuracy', color='#888')
axes[0].legend(facecolor='#1a1a2e', labelcolor='white', edgecolor='#2a2a3a')
axes[0].grid(alpha=0.15, color='#444')

axes[1].plot(epochs_range, history.history['loss'],     color='#00d4ff', linewidth=2, label='Train')
axes[1].plot(epochs_range, history.history['val_loss'], color='#ff6b6b', linewidth=2, label='Validation')
axes[1].set_title('Model Loss', color='white', fontsize=13, pad=12)
axes[1].set_xlabel('Epoch', color='#888')
axes[1].set_ylabel('Loss', color='#888')
axes[1].legend(facecolor='#1a1a2e', labelcolor='white', edgecolor='#2a2a3a')
axes[1].grid(alpha=0.15, color='#444')

plt.tight_layout()
plt.savefig('model/training_curves.png', dpi=120, bbox_inches='tight', facecolor='#0d0d14')
plt.close()

print("\n📁 Saved:")
print("   model/mnist_cnn.h5")
print("   model/training_history.json")
print("   model/training_curves.png")
print("\nNow run:  python app.py")
